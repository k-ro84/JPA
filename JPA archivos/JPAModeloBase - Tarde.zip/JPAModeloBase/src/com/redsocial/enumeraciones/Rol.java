
package com.redsocial.enumeraciones;

/*Por el momento.. crearlo aunque no tenga mucho sentido, es para ir adaptandose a futuros "roles:
que puede tener un usuario*/
public enum Rol {
    ADMIN, USER;
}
